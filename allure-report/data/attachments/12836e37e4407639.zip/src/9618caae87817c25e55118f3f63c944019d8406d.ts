import {Page, Locator} from "@playwright/test";

export class MyAccountPage {

    private readonly page: Page;

    private readonly myAccountHeader : Locator;
    private readonly logoutLink :Locator;

    constructor(page: Page){
        this.page = page;

        this.myAccountHeader = page.locator('#content h1').filter({hasText: 'My Account'});
        this.logoutLink = page.getByRole('link', {name: 'Logout'});

    }

    async isMyaccountPageExists(){
        try{
            return await this.myAccountHeader.isVisible();
        }catch(error){
            console.log('Error checking My Account Page :', error);
            return false;
        }
    }

    async isAccountLogoutLinkExists():Promise<boolean>{
        try{
             await this.logoutLink.waitFor({
                state: 'visible',
                timeout: 10000,
            })
            return true;
        }catch(error){
            console.log('Error checking my account logout link :', error);
        return false;
    }
    }


}

