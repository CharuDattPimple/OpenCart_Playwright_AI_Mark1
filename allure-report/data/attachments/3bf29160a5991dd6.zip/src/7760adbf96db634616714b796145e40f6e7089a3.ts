import {test,expect} from '@playwright/test';
import { DataGenerator } from '../../utils/dataGenerator';
import dotenv from 'dotenv';
import {Routes} from '../../api/endpoints/routes';

dotenv.config({override : true});


test.describe('Create a new user and authenticate',() =>{

const BASE_URL = process.env.API_BASE_URL || Routes.BASE_URL;
// const VALID_USERNAME = DataGenerator.getUsername();
// const VALID_PASSWORD = DataGenerator.getPassword();
// const REGISTER_USERNAME = VALID_USERNAME;
// const REGISTER_PASSWORD = VALID_PASSWORD;

 const createUserPayload = DataGenerator.generateUserPayload();
 const VALID_USERNAME = createUserPayload.username;
const VALID_PASSWORD = createUserPayload.password;
const loginPayload = {
            username : VALID_USERNAME,
            password : VALID_PASSWORD
        };

test('POST - Create a user @master @api',async({request}) => {
    // const payload = DataGenerator.generateUserPayload();
    const response = await request.post(`${BASE_URL}${Routes.CREATE_USER}`, { data : createUserPayload});
    expect(response.status()).toBe(201);
    const responseBody = await response.json();
    expect(responseBody).toHaveProperty('id');
    console.log(`User create successfully using username ${VALID_USERNAME} and password ${VALID_PASSWORD}`)
})

test('POST - Verify authentication @master @api',async({request}) => {
    console.log(`username ${VALID_USERNAME} and password ${VALID_PASSWORD}`)
    const response = await request.post(`${BASE_URL}${Routes.AUTH_LOGIN}`,{
        data : loginPayload
    });

    expect(response.status()).toBe(201);
    const responseBody = await response.json();

    expect(responseBody).toHaveProperty('token');
    expect(typeof responseBody.token).toBe('string');
    expect(responseBody.token.length).toBeGreaterThan(0);
    const token = responseBody.token;
     console.log(`User authenticated successfully using username ${VALID_USERNAME} and password ${VALID_PASSWORD} and got token as ${token}`)
})
})
