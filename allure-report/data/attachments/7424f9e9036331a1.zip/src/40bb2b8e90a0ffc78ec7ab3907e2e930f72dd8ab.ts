import { test, expect } from '../../fixtures/pageFixtures';
import { DataGenerator } from '../../utils/dataGenerator';

test.describe.serial('Opencart - Customer Registration using UI + Admin + DB Validation @master @e2e', () => {
        const firstName: string = DataGenerator.getFirstName();
        const lastName: string = DataGenerator.getLastName();
        const email: string = DataGenerator.getEmail();
        const password: any = DataGenerator.getPassword();

    test('Register a customer with random data using UI ', async ({ registerPage, homePage, sucessPage, myAccountPage }) => {
        

        await test.step('1) User Opens the application', async () => {
            await homePage.navigateTo(process.env.APP_URL || 'http://localhost/opencart/upload/');
        });

        await test.step('2) Register a new customer using dynamically generated unique data.', async () => {
            await homePage.clickMyAccount();
            await homePage.clickRegister();

            // const isRegisterPage : boolean  = await registerPage.isRegisterPageExists();
            // expect(isRegisterPage).toBeTruthy();

            await registerPage.completeRegistration(firstName, lastName, email, password);
        })

        await test.step('3) Verify that the user is registered successfully', async () => {
            const isSuccess: boolean = await sucessPage.isSucccessPageExists();
            expect(isSuccess).toBeTruthy();

            // const successMessage : string | null = await sucessPage.getSuccessMessage();
            // expect(successMessage).toContain('Your Account Has Been Created!');

            await sucessPage.clickContinueButton();
            const isMyAccount: boolean = await myAccountPage.isMyaccountPageExists();
            expect(isMyAccount).toBeTruthy();
        })

    })

    test('Verify the register customer is in Opencart Admin portal @master @e2e', async ({homePage,adminLoginPage,adminHomePage,customersPage}) => {
        const adminEmail : any  = process.env.APP_EMAIL;
        const adminPassword: any = process.env.APP_PASSWORD;

        await test.step('1) Open the OpenCart Admin Portal', async () => {
            await homePage.navigateTo(process.env.ADMIN_APP_URL || 'http://localhost/opencart/upload/admin/');
           
        })
        await test.step('2) Log in using configured administrator credentials', async () => {
            await adminLoginPage.adminLogin(adminEmail,adminPassword);
            await adminLoginPage.closePopUp();
        })
        await test.step('3) Navigate to the Customers section', async () => {
            await adminHomePage.navigateToCustomers();
        })
        await test.step('4) Search for the customer using the unique email address ', async () => {
            await customersPage.searchCustomer(email);
        })
        await test.step('5) Verify that the customer exists', async () => {
            expect(await customersPage.getCustomerEmail()).toContain(email);
        })
        await test.step('6) Open the customer record/details when applicable and verify its details', async () => {
            expect(await customersPage.getCustomerFirstName()).toContain(firstName);
            expect(await customersPage.getCustomerLastName()).toContain(lastName);
            expect(await customersPage.getCustomerEmailAfterOpen()).toContain(email);

            expect(await customersPage.getStatusValue()).toBeTruthy();
        })

    })

    test('Verify the customer record in the MySQL oc_customer table', async ({ }) => {

    })

})