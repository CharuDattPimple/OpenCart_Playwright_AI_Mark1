import {Page,Locator} from '@playwright/test';

export class HomePage {
    private readonly page: Page;
    //locators
    private readonly myAccountLink: Locator;
    private readonly registerLink: Locator;

    constructor(page: Page){
        this.page= page;
        //Initialize locator
        this.myAccountLink = page.getByRole('link', {name: 'My Account',exact: true,});
        this.registerLink =page.getByRole('link', { name: 'Register' });
    }

    async navigateTo(url: string): Promise<void>{
        await this.page.goto(url);
    }
    async clickMyAccount(){
    await this.myAccountLink.click();
    }
    async clickRegister(){
        await this.registerLink.click();
        await this.page.waitForLoadState('networkidle'); // Wait for the page to load completely
    }
}