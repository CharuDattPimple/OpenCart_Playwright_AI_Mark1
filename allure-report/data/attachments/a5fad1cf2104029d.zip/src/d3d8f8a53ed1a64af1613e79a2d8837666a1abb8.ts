import {test as base, expect} from '@playwright/test';
import dotenv from 'dotenv';

import { RegisterPage } from '../pages/registerPage';
import {HomePage} from '../pages/homePage';
import { SuccessPage } from '../pages/successPage';
import { MyAccountPage} from "../pages/myAccountPage";

// Load environment variables from .env file
dotenv.config();

const APP_URL = process.env.APP_URL || 'http://localhost/opencart/upload/';

// Define the PageFixture type that extends Playwright's test with custom fixtures
type PageFixture = {
  // The registerPage fixture provides a RegisterPage instance for testing
  registerPage: RegisterPage;
  homePage: HomePage;
  sucessPage: SuccessPage;
  myAccountPage : MyAccountPage;
};

// Export the extended test with custom fixtures
export const test = base.extend<PageFixture>({
    homePage: async ({ page }, use) => {
        // page.goto(APP_URL); 
        const homePage = new HomePage(page);
        await use(homePage);
    },
    registerPage: async ({ page }, use) => {
        const registerPage = new RegisterPage(page);
        await use(registerPage);
    },
    sucessPage : async ({page},use) => {
        const sucessPage = new SuccessPage(page);
        await use(sucessPage);
    },
    myAccountPage : async ({page},use) => {
        const myAccountPage = new MyAccountPage(page);
        await use(myAccountPage);
    }
    });
    


export { expect } from '@playwright/test';
